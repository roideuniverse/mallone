/**
 * 
 */
package com.example.myProj1.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Widget;

/**
 * @author roide
 *
 */
public class MyProjUiBinder extends Composite {

	private static MyProjUiBinderUiBinder uiBinder = GWT
			.create(MyProjUiBinderUiBinder.class);

	interface MyProjUiBinderUiBinder extends UiBinder<Widget, MyProjUiBinder> {
	}

	@UiField
	Button button;

	public MyProjUiBinder(String firstName) {
		initWidget(uiBinder.createAndBindUi(this));

		// Can access @UiField after calling createAndBindUi
		button.setText(firstName);
	}

	@UiHandler("button")
	void onClick(ClickEvent e) {
		Window.alert("Hello!");
	}

}
